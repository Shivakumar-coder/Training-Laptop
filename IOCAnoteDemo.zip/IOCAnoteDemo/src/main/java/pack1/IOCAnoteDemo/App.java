package pack1.IOCAnoteDemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import pack1.Address;
import pack1.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext cont=new AnnotationConfigApplicationContext();
        cont.scan("pack1");
        cont.refresh();
        
        Customer c1=(Customer)cont.getBean("customer");
        c1.setCustId("100");
        c1.setCustName("Shivakumar");
        
        Address ad1=c1.getAddress();
        ad1.setDoorNo("123");
        ad1.setStreet("EWIT road");
        ad1.setState("Karnataka");
        ad1.setPin("560001");
        
        System.out.println(c1);
        cont.close();
        
    }
}
